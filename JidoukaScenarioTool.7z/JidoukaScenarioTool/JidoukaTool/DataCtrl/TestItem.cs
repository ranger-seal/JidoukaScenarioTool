using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace JidoukaTool.DataCtrl
{
	class TestItem
	{
		public string name;
		public string command_setting;
		public string command_csv; 

		public bool isSelected { get; set; }

		public TestItem(string name, string command1, string command2, bool isSelected = false)
		{
			this.name = name;
			this.command_setting = command1;
			this.command_csv = command2;
			this.isSelected = isSelected;
		}
	}
}
