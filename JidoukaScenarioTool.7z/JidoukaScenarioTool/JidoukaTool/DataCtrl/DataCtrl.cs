﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JidoukaTool.DataCtrl
{

	class DataCtrl
	{
		public enum ENUM_DATACTRL_TEST_STATE
		{
			STOP,									// 0	停止/未実行
			RUNNING,                                // 1	実行中
			ERROR,                                  // 2	エラー発生
			TERMINATION,                            // 3    中断                                  
		}

		public ENUM_DATACTRL_TEST_STATE currentTestState = ENUM_DATACTRL_TEST_STATE.STOP;
		public string currentPhase = "";
		public string currenttestname = "";
		public Process taskProcess = new Process();

		private Dictionary<string, List<TestItem>> phaseTestList = new Dictionary<string, List<TestItem>>();


		private static readonly DataCtrl instance = new DataCtrl();
		public static DataCtrl Instance
		{
			get
			{
				return instance;
			}
		}

		public int addPhaseTestList(string phaseName, List<TestItem> list)
		{
			if (this.phaseTestList.ContainsKey(phaseName))
			{
				return 1;
			}
			this.phaseTestList.Add(phaseName, list);
			return 0;
		}

		public List<TestItem> getPhaseTestList(string phaseName)
		{
			if (!this.phaseTestList.ContainsKey(phaseName))
			{
				return null;
			}
			return this.phaseTestList[phaseName];
		}

		public List<TestItem> getCurrentPhaseTestList()
		{
			return this.getPhaseTestList(currentPhase);
		}

		public List<string> getPhaseNameList()
		{
			return this.phaseTestList.Keys.ToList<string>();
		}

		public int addPhaseTestItem(string phaseName, TestItem item)
		{
			if (!this.phaseTestList.ContainsKey(phaseName))
			{
				return 1;
			}
			List<TestItem> list = phaseTestList[phaseName];

			list.Add(item);

			return 0;
		}
		public int insertPhaseTestItem(TestItem item, int index, string phaseName)
		{
			if (item == null || index < 0)
			{
				return 1;
			}
			if (!this.phaseTestList.ContainsKey(phaseName))
			{
				return 1;
			}
			List<TestItem> list = phaseTestList[phaseName];

			if (index > list.Count)
			{
				return 1;
			}

			list.Insert(index, item);

			return 0;
		}
		internal void addPhaseTestList(object name, List<TestItem> list1)
		{
			throw new NotImplementedException();
		}
	}
}
