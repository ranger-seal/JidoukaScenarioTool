using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using JidoukaTool.DataCtrl;
namespace JidoukaTool.Gui
{
	public partial class MainForm : Form
	{
		public string fileSetPath = "";
		public string logSavePath = "";
		private ItemSelectForm itemSelForm = null;

		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			bool ret =realPhaseXml();

			comboBox_phaseSelect.DataSource = DataCtrl.DataCtrl.Instance.getPhaseNameList();

			DataCtrl.DataCtrl.Instance.currentPhase = comboBox_phaseSelect.Text;

			//8月20日在此增加1个判断，确认xml里是否有路径，没有就默认用桌面路径
			if (this.textBox_fileSetPath.Text == "")
			{
				this.textBox_fileSetPath.Text = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
			}
			if (this.textBox_logSavePath.Text == "")
			{
				this.textBox_logSavePath.Text = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
			}

		}



		private bool realPhaseXml() 
		{
			int i = 0;
			List<string> itemnames = new List<string>();
			List<TestItem> itemList;

			string strFromPath = @"GUIxml";

			string strFolderName = strFromPath.Substring(strFromPath.LastIndexOf("\\") + 1, strFromPath.Length - strFromPath.LastIndexOf("\\") - 1);
			string[] strFiles = Directory.GetFiles(strFromPath);


			for (i = 0; i < strFiles.Length; i++)
			{
				string strFileName = strFiles[i].Substring(strFiles[i].LastIndexOf("\\") + 1, strFiles[i].Length - strFiles[i].LastIndexOf("\\") - 1);
				string xmlname = @".\GUIxml\" + strFileName;
				string[] phaseversion =new string[strFiles.Length];
				itemList = new List<TestItem>();
				XDocument document = XDocument.Load(xmlname);
				document.Declaration = new XDeclaration("1.0", "Shift-JIS", null);
				XElement root = document.Root;
				IEnumerable<XElement> enumerable = root.Elements();
				
				foreach (XElement item in enumerable)
				{
					foreach (XElement item1 in item.Elements())
					{						
						phaseversion[i] = item.Name.ToString();
						foreach (XElement item2 in item1.Elements())							
						{
							itemnames.Add(item2.Value.ToString());				

						}
						itemList.Add(new TestItem(itemnames[0], itemnames[1], itemnames[2], itemnames[3] == "true" ? true : false));

						itemnames.Clear();
						
					}
				}
				DataCtrl.DataCtrl.Instance.addPhaseTestList(strFileName.Replace(".xml",""), itemList);
			}
			return true ;
		}
    

		private void button_fileSetPath_Click(object sender, EventArgs e)//选择获取的fileset路径
		{
			
			if (folderBrowserDialog_fileSet.ShowDialog() == DialogResult.OK)
			{
				this.fileSetPath = folderBrowserDialog_fileSet.SelectedPath;
				textBox_fileSetPath.Text = fileSetPath;
			}
			
		}

		private void button_logSavePath_Click(object sender, EventArgs e)//选择存放log的路径
		{			
			if (folderBrowserDialog_logSave.ShowDialog() == DialogResult.OK)
			{
				this.logSavePath = folderBrowserDialog_logSave.SelectedPath;
				textBox_logSavePath.Text = logSavePath;
			}
		}

		private void comboBox_phaseSelect_SelectedIndexChanged(object sender, EventArgs e)//xml选择按钮
		{
			DataCtrl.DataCtrl.Instance.currentPhase = comboBox_phaseSelect.Text;//单击第一个窗口项目选择后，显示的版本 19A 19B等
			
			if (this.itemSelForm != null && this.itemSelForm.IsDisposed)
			{
				this.itemSelForm.loadTestItem();
			}


			string xmlname = @".\GUIxml\" + DataCtrl.DataCtrl.Instance.currentPhase + @".xml";
			XDocument document = XDocument.Load(xmlname);
			document.Declaration= new XDeclaration("1.0", "Shift-JIS", null);
			XElement root = document.Root;
			IEnumerable<XElement> enumerable = root.Elements();
			foreach (XElement item in enumerable)
			{
				if (item.ToString().Contains("filesetpath"))
				{
					this.textBox_fileSetPath.Text = item.Value;
				}

				if (item.ToString().Contains("logsavepath"))
				{
					this.textBox_logSavePath.Text = item.Value;
				}

			}
			if (DataCtrl.DataCtrl.Instance.currentPhase != "")
			{
				document.Save(@".\GUIxml\" + DataCtrl.DataCtrl.Instance.currentPhase.ToString() + ".xml");
			}
			if ((this.itemSelForm != null) && (!this.itemSelForm.IsDisposed))
			{
				this.itemSelForm.fileSetPath = this.textBox_fileSetPath.Text;
				this.itemSelForm.logSavePath = this.textBox_logSavePath.Text;//修改传入的路径
			}



		}

		private void button_itemSelect_Click(object sender, EventArgs e)//项目选择按钮
		{
			if ((this.itemSelForm == null) || (this.itemSelForm.IsDisposed))
			{
				
				this.itemSelForm = new ItemSelectForm();
				this.itemSelForm.Show();
			}
			else
			{
				this.itemSelForm.Activate();
			}
				
			this.itemSelForm.fileSetPath = this.textBox_fileSetPath.Text;
			this.itemSelForm.logSavePath = this.textBox_logSavePath.Text;//路径传到第二个窗口
			this.itemSelForm.cpFileset = this.ck_fileset.Checked;
			this.itemSelForm.cpLogsave = this.ck_logsave.Checked;
            
		}

		private void MainForm_Closing(object sender, FormClosingEventArgs e)//关闭第一个窗口
		{
			if ( !( (this.itemSelForm == null) ||  (this.itemSelForm.IsDisposed)) )
			{
				this.itemSelForm.Close();
			}
		}

		private void textBox_fileSetPath_TextChanged(object sender, EventArgs e)
		{
			string xmlname = @".\GUIxml\" + DataCtrl.DataCtrl.Instance.currentPhase + @".xml";
			XDocument document = XDocument.Load(xmlname);
			document.Declaration = new XDeclaration("1.0", "Shift-JIS", null);
			XElement root = document.Root;
			IEnumerable<XElement> enumerable = root.Elements();
			//this.textBox_fileSetPath.Text = "";
			//this.textBox_logSavePath.Text = "";
			foreach (XElement item in enumerable)
			{
				//增加自动从xml文件里读取fileset和logsave地址
				if (item.ToString().Contains("filesetpath"))
				{
					item.Value = this.textBox_fileSetPath.Text;
				}

				if (item.ToString().Contains("logsavepath"))
				{
					item.Value = this.textBox_logSavePath.Text;
				}

			}




			if (DataCtrl.DataCtrl.Instance.currentPhase != "")
			{
				document.Save(@".\GUIxml\" + DataCtrl.DataCtrl.Instance.currentPhase.ToString() + ".xml");
			}

			if ((this.itemSelForm != null) && (!this.itemSelForm.IsDisposed))
			{
				this.itemSelForm.fileSetPath = this.textBox_fileSetPath.Text;
				this.itemSelForm.logSavePath = this.textBox_logSavePath.Text;//路径一有变化，就传到第二个窗口
			}

		}

		private void textBox_logSavePath_TextChanged_1(object sender, EventArgs e)
		{
			string xmlname = @".\GUIxml\" + DataCtrl.DataCtrl.Instance.currentPhase + @".xml";
			XDocument document = XDocument.Load(xmlname);
			document.Declaration = new XDeclaration("1.0", "Shift-JIS", null);
			XElement root = document.Root;
			IEnumerable<XElement> enumerable = root.Elements();

			foreach (XElement item in enumerable)
			{
				//增加自动从xml文件里读取fileset和logsave地址
				if (item.ToString().Contains("filesetpath"))
				{
					item.Value = this.textBox_fileSetPath.Text;
				}

				if (item.ToString().Contains("logsavepath"))
				{
					item.Value = this.textBox_logSavePath.Text;
				}

			}




			if (DataCtrl.DataCtrl.Instance.currentPhase != "")
			{
				document.Save(@".\GUIxml\" + DataCtrl.DataCtrl.Instance.currentPhase.ToString() + ".xml");
			}

			if ((this.itemSelForm != null) && (!this.itemSelForm.IsDisposed))
			{
				this.itemSelForm.fileSetPath = this.textBox_fileSetPath.Text;
				this.itemSelForm.logSavePath = this.textBox_logSavePath.Text;//路径一有变化，就传到第二个窗口
			}

		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void textBox_fileSetPath_DragDrop(object sender, DragEventArgs e)
		{
			Array file = (System.Array)e.Data.GetData(DataFormats.FileDrop);
			string fileText = null;
			foreach (object I in file)
			{
				fileText += I.ToString();
				fileText += "\n";
			}
			textBox_fileSetPath.Text = fileText;
		}

		private void textBox_fileSetPath_DragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				e.Effect = DragDropEffects.Link;
			}
			else
			{
				e.Effect = DragDropEffects.None;
			}
		}

		private void textBox_logSavePath_DragDrop(object sender, DragEventArgs e)
		{
			Array file = (System.Array)e.Data.GetData(DataFormats.FileDrop);
			string fileText = null;
			foreach (object I in file)
			{
				fileText += I.ToString();
				fileText += "\n";
			}

			textBox_logSavePath.Text = fileText;
		}

		private void textBox_logSavePath_DragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				e.Effect = DragDropEffects.Link;
			}
			else
			{
				e.Effect = DragDropEffects.None;
			}

		}
	}
}
