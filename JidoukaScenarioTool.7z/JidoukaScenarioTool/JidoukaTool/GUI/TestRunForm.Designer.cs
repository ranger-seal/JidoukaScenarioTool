namespace JidoukaTool.Gui
{
	partial class TestRunForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestRunForm));
			this.dataGridView_TestItem = new System.Windows.Forms.DataGridView();
			this.TestRunGrid_ItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.state = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.leftTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.label1 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView_TestItem)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGridView_TestItem
			// 
			this.dataGridView_TestItem.AllowUserToAddRows = false;
			this.dataGridView_TestItem.AllowUserToDeleteRows = false;
			this.dataGridView_TestItem.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGridView_TestItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView_TestItem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TestRunGrid_ItemName,
            this.state,
            this.leftTime});
			this.dataGridView_TestItem.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView_TestItem.Location = new System.Drawing.Point(0, 31);
			this.dataGridView_TestItem.Margin = new System.Windows.Forms.Padding(4);
			this.dataGridView_TestItem.Name = "dataGridView_TestItem";
			this.dataGridView_TestItem.ReadOnly = true;
			this.dataGridView_TestItem.RowHeadersVisible = false;
			this.dataGridView_TestItem.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToFirstHeader;
			this.dataGridView_TestItem.RowTemplate.Height = 23;
			this.dataGridView_TestItem.Size = new System.Drawing.Size(693, 531);
			this.dataGridView_TestItem.TabIndex = 0;
			this.dataGridView_TestItem.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_TestItem_CellContentClick);
			// 
			// TestRunGrid_ItemName
			// 
			this.TestRunGrid_ItemName.HeaderText = "テスト名";
			this.TestRunGrid_ItemName.MinimumWidth = 6;
			this.TestRunGrid_ItemName.Name = "TestRunGrid_ItemName";
			this.TestRunGrid_ItemName.ReadOnly = true;
			// 
			// state
			// 
			this.state.HeaderText = "状態";
			this.state.MinimumWidth = 6;
			this.state.Name = "state";
			this.state.ReadOnly = true;
			// 
			// leftTime
			// 
			this.leftTime.HeaderText = "残り時間";
			this.leftTime.MinimumWidth = 6;
			this.leftTime.Name = "leftTime";
			this.leftTime.ReadOnly = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Dock = System.Windows.Forms.DockStyle.Top;
			this.label1.Location = new System.Drawing.Point(0, 0);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Padding = new System.Windows.Forms.Padding(8);
			this.label1.Size = new System.Drawing.Size(83, 31);
			this.label1.TabIndex = 1;
			this.label1.Text = "実験状態";
			// 
			// TestRunForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(693, 562);
			this.Controls.Add(this.dataGridView_TestItem);
			this.Controls.Add(this.label1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "TestRunForm";
			this.Text = "TestRunForm";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TestRunForm_Closing);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView_TestItem)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.DataGridView dataGridView_TestItem;
		private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TestRunGrid_ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn state;
        private System.Windows.Forms.DataGridViewTextBoxColumn leftTime;
    }
}