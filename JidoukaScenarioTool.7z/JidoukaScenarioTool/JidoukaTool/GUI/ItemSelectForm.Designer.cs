﻿namespace JidoukaTool.Gui
{
	partial class ItemSelectForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ItemSelectForm));
			this.button_start = new System.Windows.Forms.Button();
			this.button_stop = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.checkedListBox_itemList = new System.Windows.Forms.CheckedListBox();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.ToolStripMenuItem_moveUp = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItem_moveDown = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem_edit = new System.Windows.Forms.ToolStripMenuItem();
			this.新增ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.panel2 = new System.Windows.Forms.Panel();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.contextMenuStrip1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// button_start
			// 
			this.button_start.Dock = System.Windows.Forms.DockStyle.Left;
			this.button_start.Location = new System.Drawing.Point(8, 4);
			this.button_start.Margin = new System.Windows.Forms.Padding(4);
			this.button_start.Name = "button_start";
			this.button_start.Size = new System.Drawing.Size(201, 51);
			this.button_start.TabIndex = 2;
			this.button_start.Text = "起動";
			this.button_start.UseVisualStyleBackColor = true;
			this.button_start.Click += new System.EventHandler(this.button_start_Click);
			// 
			// button_stop
			// 
			this.button_stop.Dock = System.Windows.Forms.DockStyle.Right;
			this.button_stop.Location = new System.Drawing.Point(438, 4);
			this.button_stop.Margin = new System.Windows.Forms.Padding(4);
			this.button_stop.Name = "button_stop";
			this.button_stop.Size = new System.Drawing.Size(199, 51);
			this.button_stop.TabIndex = 2;
			this.button_stop.Text = "停止";
			this.button_stop.UseVisualStyleBackColor = true;
			this.button_stop.Click += new System.EventHandler(this.button_stop_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Dock = System.Windows.Forms.DockStyle.Top;
			this.label1.Font = new System.Drawing.Font("宋体", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.label1.Location = new System.Drawing.Point(0, 0);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Padding = new System.Windows.Forms.Padding(8, 8, 0, 8);
			this.label1.Size = new System.Drawing.Size(152, 33);
			this.label1.TabIndex = 0;
			this.label1.Text = "プロジェクト一覧";
			// 
			// checkedListBox_itemList
			// 
			this.checkedListBox_itemList.AllowDrop = true;
			this.checkedListBox_itemList.CheckOnClick = true;
			this.checkedListBox_itemList.ContextMenuStrip = this.contextMenuStrip1;
			this.checkedListBox_itemList.Dock = System.Windows.Forms.DockStyle.Fill;
			this.checkedListBox_itemList.FormattingEnabled = true;
			this.checkedListBox_itemList.HorizontalScrollbar = true;
			this.checkedListBox_itemList.IntegralHeight = false;
			this.checkedListBox_itemList.Location = new System.Drawing.Point(0, 33);
			this.checkedListBox_itemList.Margin = new System.Windows.Forms.Padding(8);
			this.checkedListBox_itemList.Name = "checkedListBox_itemList";
			this.checkedListBox_itemList.Size = new System.Drawing.Size(645, 568);
			this.checkedListBox_itemList.TabIndex = 0;
			this.checkedListBox_itemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_itemCheck);
			this.checkedListBox_itemList.SelectedIndexChanged += new System.EventHandler(this.checkedListBox_itemList_SelectedIndexChanged_1);
			this.checkedListBox_itemList.DragDrop += new System.Windows.Forms.DragEventHandler(this.checkedListBox_itemList_DragDrop);
			this.checkedListBox_itemList.DragOver += new System.Windows.Forms.DragEventHandler(this.checkedListBox_itemList_DragOver);
			this.checkedListBox_itemList.MouseDown += new System.Windows.Forms.MouseEventHandler(this.checkedListBox_itemList_MouseDown);
			this.checkedListBox_itemList.MouseHover += new System.EventHandler(this.checkedListBox_itemList_MouseHover);
			this.checkedListBox_itemList.MouseMove += new System.Windows.Forms.MouseEventHandler(this.checkedListBox_itemList_MouseMove);
			this.checkedListBox_itemList.MouseUp += new System.Windows.Forms.MouseEventHandler(this.checkedListBox_itemList_MouseUp);
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_moveUp,
            this.ToolStripMenuItem_moveDown,
            this.toolStripMenuItem_edit,
            this.新增ToolStripMenuItem,
            this.删除ToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(139, 124);
			this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
			// 
			// ToolStripMenuItem_moveUp
			// 
			this.ToolStripMenuItem_moveUp.Name = "ToolStripMenuItem_moveUp";
			this.ToolStripMenuItem_moveUp.Size = new System.Drawing.Size(138, 24);
			this.ToolStripMenuItem_moveUp.Text = "上に移動";
			this.ToolStripMenuItem_moveUp.Click += new System.EventHandler(this.ToolStripMenuItem_move_Click);
			// 
			// ToolStripMenuItem_moveDown
			// 
			this.ToolStripMenuItem_moveDown.Name = "ToolStripMenuItem_moveDown";
			this.ToolStripMenuItem_moveDown.Size = new System.Drawing.Size(138, 24);
			this.ToolStripMenuItem_moveDown.Text = "下に移動";
			this.ToolStripMenuItem_moveDown.Click += new System.EventHandler(this.ToolStripMenuItem_move_Click);
			// 
			// toolStripMenuItem_edit
			// 
			this.toolStripMenuItem_edit.Name = "toolStripMenuItem_edit";
			this.toolStripMenuItem_edit.Size = new System.Drawing.Size(138, 24);
			this.toolStripMenuItem_edit.Text = "編集";
			this.toolStripMenuItem_edit.Click += new System.EventHandler(this.toolStripMenuItem_edit_Click);
			// 
			// 新增ToolStripMenuItem
			// 
			this.新增ToolStripMenuItem.Name = "新增ToolStripMenuItem";
			this.新增ToolStripMenuItem.Size = new System.Drawing.Size(138, 24);
			this.新增ToolStripMenuItem.Text = "追加";
			this.新增ToolStripMenuItem.Click += new System.EventHandler(this.toolStripMenuItem_add_Click);
			// 
			// 删除ToolStripMenuItem
			// 
			this.删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
			this.删除ToolStripMenuItem.Size = new System.Drawing.Size(138, 24);
			this.删除ToolStripMenuItem.Text = "削除";
			this.删除ToolStripMenuItem.Click += new System.EventHandler(this.toolStripMenuItem_delete_Click);
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.button_stop);
			this.panel2.Controls.Add(this.button_start);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel2.Location = new System.Drawing.Point(0, 601);
			this.panel2.Margin = new System.Windows.Forms.Padding(4);
			this.panel2.Name = "panel2";
			this.panel2.Padding = new System.Windows.Forms.Padding(8, 4, 8, 4);
			this.panel2.Size = new System.Drawing.Size(645, 59);
			this.panel2.TabIndex = 3;
			// 
			// toolTip1
			// 
			this.toolTip1.ShowAlways = true;
			this.toolTip1.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTip1_Popup);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
			// 
			// ItemSelectForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(645, 660);
			this.Controls.Add(this.checkedListBox_itemList);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.label1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "ItemSelectForm";
			this.Text = "5G自動化ツール";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ItemSelectForm_Closing);
			this.Load += new System.EventHandler(this.ItemSelectForm_Load);
			this.contextMenuStrip1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button button_start;
		private System.Windows.Forms.Button button_stop;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckedListBox checkedListBox_itemList;
		private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_moveUp;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_moveDown;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_edit;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem 新增ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除ToolStripMenuItem;
    }
}