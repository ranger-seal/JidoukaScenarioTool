using JidoukaTool.DataCtrl;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using JidoukaTool.GUI;
using System.Xml.Linq;
using JidoukaTool.Gui;
using System.Threading;

namespace JidoukaTool.Gui
{
	public partial class ItemSelectForm : Form
	{
		private bool isloading = false;
		private TestRunForm testRunForm;
		public string fileSetPath;
		public string logSavePath;
		private System.Windows.Forms.CheckedListBox CheckedListBox1;
		int indexofsource;//拖动的起始索引
		int indexoftarget; //拖动的结束索引
		public Boolean cpFileset;
		public Boolean cpLogsave;
		public ItemSelectForm()
		{
			InitializeComponent();
			//DataCtrl.DataCtrl.Instance.TestStateChange += new DataCtrl.DataCtrl.TestStateChangeHandler(this.testStateChange);


		}

		private void ItemSelectForm_Load(object sender, EventArgs e)//显示功能
		{
			loadTestItem();
		}

		public static void CopyFolder(string srcPath, string destPath)
		{
			try
			{
				DirectoryInfo dir = new DirectoryInfo(srcPath);
				FileSystemInfo[] fileinfo = dir.GetFileSystemInfos();  //获取目录下（不包含子目录）的文件和子目录
				foreach (FileSystemInfo i in fileinfo)
				{
					if (i is DirectoryInfo)
					{     //判断是否文件夹
						if (!Directory.Exists(destPath + "\\" + i.Name))
						{
							Directory.CreateDirectory(destPath + "\\" + i.Name);   //目标目录下不存在此文件夹即创建子文件夹
						}
						CopyFolder(i.FullName, destPath + "\\" + i.Name);    //递归调用复制子文件夹
					}
					else
					{
						File.Copy(i.FullName, destPath + "\\" + i.Name, true);      //不是文件夹即复制文件，true表示可以覆盖同名文件
					}
				}
			}
			catch (Exception e)
			{
				throw;
			}
		}

		private void button_start_Click(object sender, EventArgs e)//起动按钮
		{
			if ((this.testRunForm == null) || (this.testRunForm.IsDisposed))
			{
				if (Directory.Exists(@".\output"))//清空output文件夹
				{
					DelectDir(@".\output");
				}
                if (cpFileset)
                {
					CopyFolder(fileSetPath, "fileset");//可手动选择要获取的fileset文件夹位置，保存到根目录的fileset文件夹				
				}
				
				this.testRunForm = new TestRunForm();
				this.testRunForm.Show();
			}
			else
			{
				this.testRunForm.Activate();

			}
			this.testRunForm.logSavePath = this.logSavePath;
			this.testRunForm.fileSetPath = this.fileSetPath;
			this.testRunForm.cpLogsave = cpLogsave;
			this.testRunForm.run();

            //TestRunForm.CopylogFolder(@".\output", logSavePath);
		}


		private void button_stop_Click(object sender, EventArgs e)//停止按钮
		{
			if ((this.testRunForm == null) || (this.testRunForm.IsDisposed))
			{
				return;
			}
			else
			{
				DataCtrl.DataCtrl.Instance.currentTestState = DataCtrl.DataCtrl.ENUM_DATACTRL_TEST_STATE.TERMINATION;
				this.testRunForm.stop();
			}

		}

		public static void DelectDir(string srcPath)//删除所有文件
		{
			try
			{
				DirectoryInfo dir = new DirectoryInfo(srcPath);
				FileSystemInfo[] fileinfo = dir.GetFileSystemInfos();  //返回目录中所有文件和子目录
				foreach (FileSystemInfo i in fileinfo)
				{
					if (i is DirectoryInfo)            //判断是否文件夹
					{
						DirectoryInfo subdir = new DirectoryInfo(i.FullName);
						subdir.Delete(true);          //删除子目录和文件
					}
					else
					{
						File.Delete(i.FullName);      //删除指定文件
					}
				}
			}
			catch (Exception e)
			{
				throw;
			}
		}



		public void loadTestItem()
		{
			isloading = true;
			checkedListBox_itemList.Items.Clear();
			List<TestItem> list = DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList();
			int index = 0;

			for (int i=0;i<list.Count;i++)//增加对xml格式的判定
			{
				if (list[i].name.ToString().Length == 0)
				{
					MessageBox.Show("XML Test name error:null");
				}
				if (list[i].command_csv.ToString().Length == 0)
				{
					MessageBox.Show("XML Test command_csv error:null");
				}

				if (list[i].command_setting.ToString().Length == 0)
				{
					MessageBox.Show("XML Test command_setting error:null");
				}
				if (list[i].isSelected.ToString().Length == 0)
				{
					MessageBox.Show("XML Test isSelected error:null");
				}
			}

			foreach (TestItem item in list)
			{
				checkedListBox_itemList.Items.Add(item.name);	

				if (item.isSelected == true)
				{
					checkedListBox_itemList.SetItemChecked(index, true);
				}
				index++;
			}			

			isloading = false;

		}

		private void checkedListBox_itemCheck(object sender, ItemCheckEventArgs e)//实现打勾的功能
		{
			if (isloading)
			{
				return;
			}
			if (checkedListBox_itemList.IndexFromPoint(
							checkedListBox_itemList.PointToClient(Cursor.Position).X,
							checkedListBox_itemList.PointToClient(Cursor.Position).Y) == -1)
			{
				e.NewValue = e.CurrentValue;
				checkedListBox_itemList.ClearSelected();
				return;
			}


			List<TestItem> list = DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList();
			if (e.NewValue == CheckState.Checked)
			{
				list[e.Index].isSelected = true;
			}
			else
			{
				list[e.Index].isSelected = false;
			}
			XML_write();
			//添加单击选框 写入xml文件

			//以下为xml文件的写入
			/*XDocument document = new XDocument();
			document.Declaration = new XDeclaration("1.0", "Shift-JIS", null);
			XElement root = new XElement("root");
			document.Add(root);
			XElement filesetpath = new XElement("filesetpath");//路径1
			XElement logsavepath = new XElement("logsavepath");//路径2
			XElement phase = new XElement("phase" + DataCtrl.DataCtrl.Instance.currentPhase.ToString());//19A  19B

			
			for (int j = 0; j < checkedListBox_itemList.Items.Count; j++) //itemIndex是实验的编号

			{
				XElement Project = new XElement("Project" + j.ToString());
				Project.SetElementValue("name", list[j].name);//checkedListBox_itemList.Items[j]是实验的名称
				Project.SetElementValue("command1", list[j].command_setting);
				Project.SetElementValue("command2", list[j].command_csv);
				Project.SetElementValue("isSelected", list[j].isSelected);
				phase.Add(Project);
			}
			root.Add(filesetpath);
			root.SetElementValue("filesetpath", fileSetPath);
			root.Add(logsavepath);
			root.SetElementValue("logsavepath", logSavePath);
			root.Add(phase);
			document.Save(@".\GUIxml\" + DataCtrl.DataCtrl.Instance.currentPhase.ToString() + ".xml");*/
		}



		public  void XML_write()
		{
			List<TestItem> list = DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList();
			XDocument document = new XDocument();
			document.Declaration = new XDeclaration("1.0", "Shift-JIS", null);
			XElement root = new XElement("root");
			document.Add(root);
			XElement filesetpath = new XElement("filesetpath");//路径1
			XElement logsavepath = new XElement("logsavepath");//路径2
			XElement phase = new XElement("phase" + DataCtrl.DataCtrl.Instance.currentPhase.ToString());//19A  19B


			for (int j = 0; j < checkedListBox_itemList.Items.Count; j++) //itemIndex是实验的编号

			{
				XElement Project = new XElement("Project" + j.ToString());
				Project.SetElementValue("name", list[j].name);//checkedListBox_itemList.Items[j]是实验的名称
				Project.SetElementValue("command1", list[j].command_setting);
				Project.SetElementValue("command2", list[j].command_csv);
				Project.SetElementValue("isSelected", list[j].isSelected);
				phase.Add(Project);
			}
			root.Add(filesetpath);
			root.SetElementValue("filesetpath", fileSetPath);
			root.Add(logsavepath);
			root.SetElementValue("logsavepath", logSavePath);
			root.Add(phase);
			document.Save(@".\GUIxml\" + DataCtrl.DataCtrl.Instance.currentPhase.ToString() + ".xml");


		}









		private void ItemSelectForm_Closing(object sender, FormClosingEventArgs e)//实现关闭窗口的功能
		{
			if (!((this.testRunForm == null) || (this.testRunForm.IsDisposed)))
			{
				this.testRunForm.stop();
				this.testRunForm.Close();
			}
		}

		private void checkedListBox_itemList_SelectedIndexChanged(object sender, EventArgs e)
		{

			int index = checkedListBox_itemList.SelectedIndex;
			if (index != -1)
			{
				//loadTestItem();
				toolTip1.SetToolTip(this.checkedListBox_itemList, DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList()[index].name);//显示试验项目名称
			}
		}


		private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
		{
			int itemIndex = checkedListBox_itemList.IndexFromPoint(
										checkedListBox_itemList.PointToClient(Cursor.Position).X,
										checkedListBox_itemList.PointToClient(Cursor.Position).Y);

			if (itemIndex == -1)//如果不在框内，右键菜单就只显示新增
			{
				foreach (ToolStripMenuItem item in contextMenuStrip1.Items)
				{
					if (item != contextMenuStrip1.Items[3])
					{
						item.Visible = false;
					}
					else
					{
						item.Visible = true;
						
					}
				}
				return;
			}


			else 
			{
				foreach (ToolStripMenuItem item in contextMenuStrip1.Items)
				{
					
						item.Visible = true;
						checkedListBox_itemList.SetSelected(itemIndex, true);

				}
				return;
			}

			

		}

		private void toolTip1_Popup(object sender, PopupEventArgs e)
		{			

		}





		private void checkedListBox_itemList_SelectedIndexChanged_1(object sender, EventArgs e)
		{
			int index = checkedListBox_itemList.SelectedIndex;
			if (index != -1)
			{
				toolTip1.SetToolTip(this.checkedListBox_itemList, DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList()[index].name);//显示试验项目名称


			}
		}

		private void checkedListBox_itemList_MouseHover(object sender, EventArgs e)
		{
		}

		private void checkedListBox_itemList_MouseMove(object sender, MouseEventArgs e)
		{
			int index = ((ListBox)sender).IndexFromPoint(e.Location);
			if (index >= 0)
			{
				//loadTestItem();//5月29日 显示试验项目名称
				toolTip1.SetToolTip(this.checkedListBox_itemList, DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList()[index].name);//显示试验项目名称

			}
		}

		private void ToolStripMenuItem_move_Click(object sender, EventArgs e)//右键 实现上移下移功能
		{
			int itemIndex = checkedListBox_itemList.SelectedIndex;

			int targetIndex = itemIndex;

			List<TestItem> list = DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList();

			TestItem targetItem;

			if (itemIndex == -1)
			{
				itemIndex = 0;
				//return;
			}

			ToolStripMenuItem menuItem = sender as ToolStripMenuItem;

			if (menuItem == ToolStripMenuItem_moveUp)
			{
				if (itemIndex == 0)
				{
					return;
				}
				targetIndex = itemIndex - 1;
			}
			else if (menuItem == ToolStripMenuItem_moveDown)
			{
				if (itemIndex == checkedListBox_itemList.Items.Count - 1)
				{
					return;
				}
				targetIndex = itemIndex + 1;
			}

			targetItem = list[itemIndex];//4句

			list.RemoveAt(itemIndex);
			checkedListBox_itemList.Items.RemoveAt(itemIndex);

			list.Insert(targetIndex, targetItem);
			checkedListBox_itemList.Items.Insert(targetIndex, targetItem.name);

			isloading = true;
			checkedListBox_itemList.SetItemChecked(targetIndex, targetItem.isSelected);
			isloading = false;


			XML_write();

		}



		private void toolStripMenuItem_edit_Click(object sender, EventArgs e)//右键 编辑 弹出新窗口
		{

			label1: int itemIndex = checkedListBox_itemList.SelectedIndex;

			if (itemIndex == -1)
			{
				itemIndex = 0;
				//return;
			}

			List<TestItem> list = DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList();
			TestItem targetItem = list[itemIndex];

			ItemForm itemForm = new ItemForm(targetItem.name, targetItem.command_setting, targetItem.command_csv);
			if (itemForm.ShowDialog(this) == DialogResult.OK)
			{
				targetItem.name = itemForm.name;//将选择的名称赋给右键选择的实验项目
				targetItem.command_setting = itemForm.setting_path;
				targetItem.command_csv = itemForm.csv_path;

				if ((targetItem.name == "") | (targetItem.command_setting == "") | (targetItem.command_csv == ""))
				{
					//itemForm.Show();

					MessageBox.Show("The test name and parameters cannot be empty.");
					goto label1;
					//return;
				}


				else
				{
					checkedListBox_itemList.Items.RemoveAt(itemIndex);//删除数据
					checkedListBox_itemList.Items.Insert(itemIndex, targetItem.name);//重新写入数据到列表
					isloading = true;
					checkedListBox_itemList.SetItemChecked(itemIndex, targetItem.isSelected);
					isloading = false;



					XML_write();

				}

			}
		}


		private void testStateChange()
		{
			if (DataCtrl.DataCtrl.Instance.currentTestState == DataCtrl.DataCtrl.ENUM_DATACTRL_TEST_STATE.RUNNING)
			{
				button_start.Enabled = false;
				button_stop.Enabled = true;
			}
			else
			{
				button_start.Enabled = true;
				button_stop.Enabled = false;
			}
		}

		private void toolStripMenuItem_add_Click(object sender, EventArgs e)//右键 新增项目
		{




			label1: ItemForm itemForm = new ItemForm();

			if (itemForm.ShowDialog(this) == DialogResult.Cancel)
			{
				itemForm.Close();
				return;
			}


			else
			{
				String name = itemForm.name;
				String settingPath = itemForm.setting_path;
				String csvPath = itemForm.csv_path;

				if ((itemForm.name != "") && (itemForm.setting_path != "") && (itemForm.csv_path != ""))
				{ 

				DataCtrl.DataCtrl.Instance.insertPhaseTestItem(new TestItem(name, settingPath, csvPath),DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList().Count,DataCtrl.DataCtrl.Instance.currentPhase);

				checkedListBox_itemList.Items.Add(name);
				}
			}



			int itemIndex = checkedListBox_itemList.SelectedIndex;
			if (itemIndex == -1)
			{
				itemIndex = 0;
				//return;
			}
			List<TestItem> list = DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList();
			TestItem targetItem = list[itemIndex];

			//if(this.DialogResult != DialogResult.Cancel) button_Cancel
			//{ 
			    if ((itemForm.name == "") | (itemForm.setting_path == "") | (itemForm.csv_path == ""))
			    {
			    	//itemForm.Show();
			    	MessageBox.Show("The test name and parameters cannot be empty.");
			    	goto label1;
			    	//return;
			    }
			    else
			    {
			    	XML_write();
			    
			    }
			//}

		}

		private void toolStripMenuItem_delete_Click(object sender, EventArgs e)//实现 删除功能
		{

			int itemIndex = checkedListBox_itemList.SelectedIndex;

			if (itemIndex == -1)
			{
				itemIndex = 0;
				//return;
			}

			List<TestItem> list = DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList();
			TestItem targetItem = list[itemIndex];

			//ItemForm itemForm = new ItemForm(targetItem.name, targetItem.command_setting, targetItem.command_csv);

			checkedListBox_itemList.Items.RemoveAt(itemIndex);//删除数据,明面上可以在软件上看到的删除，但实际写到xml却不是一样的
			list.RemoveAt(itemIndex);

			XML_write();

		}
		


		//以下为实现拖动排序功能
		private void checkedListBox_itemList_MouseDown(object sender, MouseEventArgs e)
		{

			
			int itemIndex = checkedListBox_itemList.IndexFromPoint(
							checkedListBox_itemList.PointToClient(Cursor.Position).X,
							checkedListBox_itemList.PointToClient(Cursor.Position).Y);

			if (itemIndex != -1)
			{


			     if (e.Button == MouseButtons.Middle)//Left&Middle
				 { 
			              
					    indexofsource = ((CheckedListBox)sender).IndexFromPoint(e.X, e.Y);
			              
					    if (indexofsource != CheckedListBox.NoMatches)
			              
					    {
			              
						    ((CheckedListBox)sender).DoDragDrop(((CheckedListBox)sender).Items[indexofsource].ToString(), DragDropEffects.All);
			              
					    }
			     }
				

			}
		}

		private void checkedListBox_itemList_MouseUp(object sender, MouseEventArgs e)
		{

			

		}




		private void checkedListBox_itemList_DragOver(object sender, DragEventArgs e)
		{
			//拖动源和放置的目的地一定是一个ListBox
			if (e.Data.GetDataPresent(typeof(System.String)) && ((ListBox)sender).Equals(checkedListBox_itemList))
			{
				e.Effect = DragDropEffects.Move;
			}
			else
			{
				e.Effect = DragDropEffects.None;
				return;

			}
		}

		private void checkedListBox_itemList_DragDrop(object sender, DragEventArgs e)
		{
			int itemIndex = checkedListBox_itemList.SelectedIndex;
			int targetIndex = itemIndex;
			TestItem targetItem;
			List<TestItem> list = DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList();
			CheckedListBox checkedlistbox = (CheckedListBox)sender;
			indexoftarget = checkedlistbox.IndexFromPoint(checkedlistbox.PointToClient(new Point(e.X, e.Y)));
			targetItem = list[indexofsource];//4句
			if (indexoftarget != ListBox.NoMatches)
			{

				//增加读取
				list.RemoveAt(indexofsource);
				checkedListBox_itemList.Items.RemoveAt(indexofsource);
				list.Insert(indexoftarget, targetItem);
				checkedListBox_itemList.Items.Insert(indexoftarget, targetItem.name);
				isloading = true;
				checkedListBox_itemList.SetItemChecked(indexoftarget, targetItem.isSelected);
				isloading = false;

			}

			XML_write();


		}

		private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
		{

		}

		private void contextMenuStrip2_Opening(object sender, CancelEventArgs e)
		{

		}
	}
}
