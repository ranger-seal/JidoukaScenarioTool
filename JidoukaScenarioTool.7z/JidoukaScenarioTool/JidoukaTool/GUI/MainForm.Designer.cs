﻿namespace JidoukaTool.Gui
{
	partial class MainForm
	{
		/// <summary>
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows 窗体设计器生成的代码

		/// <summary>
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.comboBox_phaseSelect = new System.Windows.Forms.ComboBox();
            this.textBox_fileSetPath = new System.Windows.Forms.TextBox();
            this.button_fileSetPath = new System.Windows.Forms.Button();
            this.textBox_logSavePath = new System.Windows.Forms.TextBox();
            this.button_logSavePath = new System.Windows.Forms.Button();
            this.button_itemSelect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.folderBrowserDialog_fileSet = new System.Windows.Forms.FolderBrowserDialog();
            this.folderBrowserDialog_logSave = new System.Windows.Forms.FolderBrowserDialog();
            this.ck_fileset = new System.Windows.Forms.CheckBox();
            this.ck_logsave = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // comboBox_phaseSelect
            // 
            this.comboBox_phaseSelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_phaseSelect.FormattingEnabled = true;
            resources.ApplyResources(this.comboBox_phaseSelect, "comboBox_phaseSelect");
            this.comboBox_phaseSelect.Name = "comboBox_phaseSelect";
            this.comboBox_phaseSelect.SelectedIndexChanged += new System.EventHandler(this.comboBox_phaseSelect_SelectedIndexChanged);
            // 
            // textBox_fileSetPath
            // 
            this.textBox_fileSetPath.AllowDrop = true;
            resources.ApplyResources(this.textBox_fileSetPath, "textBox_fileSetPath");
            this.textBox_fileSetPath.Name = "textBox_fileSetPath";
            this.textBox_fileSetPath.TextChanged += new System.EventHandler(this.textBox_fileSetPath_TextChanged);
            this.textBox_fileSetPath.DragDrop += new System.Windows.Forms.DragEventHandler(this.textBox_fileSetPath_DragDrop);
            this.textBox_fileSetPath.DragEnter += new System.Windows.Forms.DragEventHandler(this.textBox_fileSetPath_DragEnter);
            // 
            // button_fileSetPath
            // 
            resources.ApplyResources(this.button_fileSetPath, "button_fileSetPath");
            this.button_fileSetPath.Name = "button_fileSetPath";
            this.button_fileSetPath.UseVisualStyleBackColor = true;
            this.button_fileSetPath.Click += new System.EventHandler(this.button_fileSetPath_Click);
            // 
            // textBox_logSavePath
            // 
            this.textBox_logSavePath.AllowDrop = true;
            resources.ApplyResources(this.textBox_logSavePath, "textBox_logSavePath");
            this.textBox_logSavePath.Name = "textBox_logSavePath";
            this.textBox_logSavePath.TextChanged += new System.EventHandler(this.textBox_logSavePath_TextChanged_1);
            this.textBox_logSavePath.DragDrop += new System.Windows.Forms.DragEventHandler(this.textBox_logSavePath_DragDrop);
            this.textBox_logSavePath.DragEnter += new System.Windows.Forms.DragEventHandler(this.textBox_logSavePath_DragEnter);
            // 
            // button_logSavePath
            // 
            resources.ApplyResources(this.button_logSavePath, "button_logSavePath");
            this.button_logSavePath.Name = "button_logSavePath";
            this.button_logSavePath.UseVisualStyleBackColor = true;
            this.button_logSavePath.Click += new System.EventHandler(this.button_logSavePath_Click);
            // 
            // button_itemSelect
            // 
            resources.ApplyResources(this.button_itemSelect, "button_itemSelect");
            this.button_itemSelect.Name = "button_itemSelect";
            this.button_itemSelect.UseVisualStyleBackColor = true;
            this.button_itemSelect.Click += new System.EventHandler(this.button_itemSelect_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // folderBrowserDialog_fileSet
            // 
            this.folderBrowserDialog_fileSet.RootFolder = System.Environment.SpecialFolder.MyComputer;
            this.folderBrowserDialog_fileSet.ShowNewFolderButton = false;
            // 
            // folderBrowserDialog_logSave
            // 
            this.folderBrowserDialog_logSave.RootFolder = System.Environment.SpecialFolder.MyComputer;
            this.folderBrowserDialog_logSave.ShowNewFolderButton = false;
            // 
            // ck_fileset
            // 
            resources.ApplyResources(this.ck_fileset, "ck_fileset");
            this.ck_fileset.Name = "ck_fileset";
            this.ck_fileset.UseVisualStyleBackColor = true;
            // 
            // ck_logsave
            // 
            resources.ApplyResources(this.ck_logsave, "ck_logsave");
            this.ck_logsave.Name = "ck_logsave";
            this.ck_logsave.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ck_logsave);
            this.Controls.Add(this.ck_fileset);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_itemSelect);
            this.Controls.Add(this.button_logSavePath);
            this.Controls.Add(this.textBox_logSavePath);
            this.Controls.Add(this.button_fileSetPath);
            this.Controls.Add(this.textBox_fileSetPath);
            this.Controls.Add(this.comboBox_phaseSelect);
            this.Name = "MainForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_Closing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ComboBox comboBox_phaseSelect;
		private System.Windows.Forms.TextBox textBox_fileSetPath;
		private System.Windows.Forms.Button button_fileSetPath;
		private System.Windows.Forms.TextBox textBox_logSavePath;
		private System.Windows.Forms.Button button_logSavePath;
		private System.Windows.Forms.Button button_itemSelect;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_fileSet;
		private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_logSave;
        public System.Windows.Forms.CheckBox ck_fileset;
        public System.Windows.Forms.CheckBox ck_logsave;
    }
}

