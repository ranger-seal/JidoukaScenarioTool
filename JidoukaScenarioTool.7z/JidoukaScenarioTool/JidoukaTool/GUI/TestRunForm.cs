using JidoukaTool.DataCtrl;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Management;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace JidoukaTool.Gui
{
	public partial class TestRunForm : Form
	{
		public Process taskProcess = new Process();
		public string logSavePath = "";
		public string csv1ifexit = "";
		public string csv2ifexit = "";
		public string filesetcheck = "";
		public string fileSetPath = "";
		private List<int> timeList;
		private Thread mtimeThread;
		public Boolean cpLogsave;
		System.Windows.Forms.Timer Mytimer;
		TimeSpan timeCount = new TimeSpan();
		DateTime timeNow;
		DateTime nowTime ;
		int testIndex;
		List<TestItem> runItemList = new List<TestItem>();
		public TestRunForm()
		{
			InitializeComponent();
		}

		public int run()
		{
			timeList = new List<int>();
			if (DataCtrl.DataCtrl.Instance.currentTestState == 	DataCtrl.DataCtrl.ENUM_DATACTRL_TEST_STATE.RUNNING)
			{
				return 1;
			}

			this.runItemList.Clear();
			DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList().ForEach((i) =>  //两个list：1个是界面上的，1个是实际的 此处的Instance是打勾所选择的项目；
			{
				if (i.isSelected)
					this.runItemList.Add(i);
			});

			dataGridView_TestItem.Rows.Clear();

			for (int i = 0; i < this.runItemList.Count; i++)//this.runItemList.Count是打勾的项目数量
			{
				int index = dataGridView_TestItem.Rows.Add();
				dataGridView_TestItem.Rows[index].Cells[0].Value = this.runItemList[i].name;//将试验的名称显示出来
				string[] file_array = System.IO.File.ReadAllLines(this.runItemList[index].command_csv, System.Text.Encoding.GetEncoding("Shift-JIS"));//将试验剩余时间显示出来
				string timeStr = file_array[file_array.Length - 1];
				string pattern = @"^\d+秒";
				Regex regex = new Regex(pattern);
                if (regex.IsMatch(timeStr))
                {
					timeStr = Regex.Replace(timeStr,@"[^0-9]+","");
					timeList.Add(int.Parse(timeStr));
					showTime(int.Parse(timeStr), dataGridView_TestItem.Rows[index].Cells[2]);
                }
                else
                {
					timeList.Add(600);
					showTime(600, dataGridView_TestItem.Rows[index].Cells[2]);
				}
			}	  
			DataCtrl.DataCtrl.Instance.currentTestState = DataCtrl.DataCtrl.ENUM_DATACTRL_TEST_STATE.RUNNING;

			     
			string filePath = @".\TestRun.bat";//生成bat文件
			if (!File.Exists(filePath))
			{
				FileStream fs1 = new FileStream(filePath, FileMode.Create, FileAccess.Write);//创建写入文件
				StreamWriter sw = new StreamWriter(fs1, Encoding.GetEncoding(932));

				//sw.WriteLine(@"route print  >%~dp0\output\1.txt%");
				string command_setting1 = this.runItemList[this.testIndex].command_setting;
				string command_csv1 = this.runItemList[this.testIndex].command_csv;
				if (command_setting1.Contains("{"))
				{
					command_setting1 = command_setting1.Replace("{", "{{");
				}
				if (command_setting1.Contains("}"))
				{
					command_setting1 = command_setting1.Replace("}", "}}");
				}

				if (command_csv1.Contains("{"))
				{
					command_csv1 = command_csv1.Replace("{", "{{");
				}
				if (command_csv1.Contains("}"))
				{
					command_csv1 = command_csv1.Replace("}", "}}");
				}


				sw.WriteLine(@"C:\Windows\System32\cscript //nologo %~dp0S3G.vbs"
							 + @" " + command_setting1
							 + @" " + command_csv1
							 + @" C:\MTSTSVR\sftp\log %~dp0mtstlog" + "\n"
							 + @"echo 'MTST:batch-END'", Encoding.GetEncoding(932));//开始写入值
				sw.Close();
				fs1.Close();
			}
			else
			{
				FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
				StreamWriter sr = new StreamWriter(fs, Encoding.GetEncoding(932));
				//sr.WriteLine(@"route print  >%~dp0\output\1.txt%");
				string command_setting2 = this.runItemList[this.testIndex].command_setting;
				string command_csv2 = this.runItemList[this.testIndex].command_csv;
				if (command_setting2.Contains("{"))
				{
					command_setting2 = command_setting2.Replace("{", "{{");
				}
				if (command_setting2.Contains("}"))
				{
					command_setting2 = command_setting2.Replace("}", "}}");
				}

				if (command_csv2.Contains("{"))
				{
					command_csv2 = command_csv2.Replace("{", "{{");
				}
				if (command_csv2.Contains("}"))
				{
					command_csv2 = command_csv2.Replace("}", "}}");
				}


				sr.WriteLine(@"C:\Windows\System32\cscript //nologo %~dp0S3G.vbs"
							 + @" " + command_setting2
							 + @" " + command_csv2
							 + @" C:\MTSTSVR\sftp\log %~dp0mtstlog" + "\n"
							 + @"echo 'MTST:batch-END'", Encoding.GetEncoding(932));//开始写入值
				sr.Close();
				fs.Close();
			}
			
			
			try//以下为bat执行
			{
				string targetDir = string.Format(@"");
				DataCtrl.DataCtrl.Instance.taskProcess = new Process();
				DataCtrl.DataCtrl.Instance.taskProcess.StartInfo.WorkingDirectory = targetDir;
				DataCtrl.DataCtrl.Instance.taskProcess.StartInfo.FileName = filePath;   //@".\TestRun.bat" 将执行的文件名是TestRun.bat
				DataCtrl.DataCtrl.Instance.taskProcess.StartInfo.Arguments = this.runItemList[this.testIndex].command_csv;//this is argument 将csv2传递过来
																								 //proc.StartInfo.CreateNoWindow = true;
																								 //proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;//这里设置DOS窗口不显示，经实践可行
				
				DataCtrl.DataCtrl.Instance.taskProcess.Start();
				DataCtrl.DataCtrl.Instance.taskProcess.EnableRaisingEvents = true;
			    this.nowTime = DateTime.Now;
			    DataCtrl.DataCtrl.Instance.taskProcess.Exited += process_exit;

				dataGridView_TestItem.Rows[this.testIndex].Cells[1].Value = "実施中...";//显示实施中
				//倒计时
				TimeTread tt = new TimeTread(timeList[this.testIndex], dataGridView_TestItem.Rows[this.testIndex].Cells[2]);
				Thread th = new Thread(new ThreadStart(tt.timeCout));
				th.Start();
				mtimeThread = th;
			}

			catch (Exception ex)
			{
			    MessageBox.Show("执行失败");
			    Console.WriteLine("Exception Occurred :{0},{1}", ex.Message, ex.StackTrace.ToString());
			}


			//以下为判定2个csv文件 setting_file 和 scenario 是否存在
			if (!File.Exists(this.runItemList[this.testIndex].command_setting))
			{
				csv1ifexit = "Execution error: The executed setting_file of CSV does not exist;";
				MessageBox.Show("Execution error: The executed setting_file of CSV does not exist;");
			}
			else
			{
			    csv1ifexit = "The executed setting_file of CSV exists;";
			}
			
			if (!File.Exists(this.runItemList[this.testIndex].command_csv))
			{
				csv2ifexit = "Execution error: The executed scenario of CSV does not exist;";
				MessageBox.Show("Execution error: The executed scenario of CSV does not exist;");
			}
			else
			{
			csv2ifexit = "The executed scenario of CSV exists;";
			}
			return 0;

		}
		
		public int stop()
		{
			if (DataCtrl.DataCtrl.Instance.currentTestState == 	DataCtrl.DataCtrl.ENUM_DATACTRL_TEST_STATE.STOP)
			{
				return 1;
			}

			if (DataCtrl.DataCtrl.Instance.currentTestState != DataCtrl.DataCtrl.ENUM_DATACTRL_TEST_STATE.TERMINATION)
			{
				DataCtrl.DataCtrl.Instance.currentTestState = DataCtrl.DataCtrl.ENUM_DATACTRL_TEST_STATE.STOP;
			}
			try
			{
				if (!DataCtrl.DataCtrl.Instance.taskProcess.HasExited)
				{
					KillProcessAndChildren(DataCtrl.DataCtrl.Instance.taskProcess.Id);//杀进程
				}
			}
			catch (Exception ex)
			{
			}

			return 0;
		}
		
		private void showTime(int timeNum,DataGridViewCell mcell)//显示剩余时间
        {
			TimeSpan tmp = new TimeSpan(0, 0, timeNum);
			mcell.Value = string.Format("{0:00}:{1:00}:{2:00}", tmp.Hours, tmp.Minutes, tmp.Seconds);
		}
		private void TestRunForm_Closing(object sender, FormClosingEventArgs e)
		{
			stop();
		}
		public string formatDateTime(string secondTime)
		{
			if (string.IsNullOrEmpty(secondTime))
			{
				return "";
			}
			else
			{
				long mss = long.Parse(secondTime);

				string DateTimes = null;
				long days = mss / (60 * 60 * 24);
				long hours = (mss % (60 * 60 * 24)) / (60 * 60);
				long minutes = (mss % (60 * 60)) / 60;
				long seconds = mss % 60;
				if (days > 0)
				{
					DateTimes = days + "天" + hours + "小时" + minutes + "分钟"
					 + seconds + "秒";
				}
				else if (hours > 0)
				{
					DateTimes = hours + "小时" + minutes + "分钟"
					 + seconds + "秒";
				}
				else if (minutes > 0)
				{
					DateTimes = minutes + "分钟"
					 + seconds + "秒";
				}
				else
				{
					DateTimes = seconds + "秒";
				}

				return DateTimes;
			}

		}
		public static void KillProcessAndChildren(int pid)//杀所有子进程以及孙进程等；
		{
			ManagementObjectSearcher searcher = new ManagementObjectSearcher("Select * From Win32_Process Where ParentProcessID=" + pid);
			ManagementObjectCollection moc = searcher.Get();
			foreach (ManagementObject mo in moc)
			{
				KillProcessAndChildren(Convert.ToInt32(mo["ProcessID"]));
			}
			try
			{
				Process proc = Process.GetProcessById(pid);
				Console.WriteLine(proc.ProcessName);
				Console.WriteLine(pid);
				proc.Kill();
			}
			catch (ArgumentException)
			{
				/* process already exited */
			}
			catch (Win32Exception)
			{

			}
			catch (InvalidOperationException)
			{

			}
		}

		public void process_exit(object sender, EventArgs e)
		{
			Console.WriteLine("process_exit");
			int BPR_FP_FEF_count = 0;
			int CLK_FD_FEF_count = 0;
			int DS_FM_FEF_count = 0;
			int DS_FP_FEF_count = 0;
			int EBLI_BT_FEF_count = 0;
			int EBLI_FP_FEF_count = 0;
			int EBLI_NWP_FEF_count = 0;
			int MPC_BT_FEF_count = 0;			
			int MPC_CPU_FEF_count = 0;
			int MPC_FP_FEF_count = 0;
			int BB_FD_FGF_count = 0;
			int ELL_L_FD_FGF_count = 0;
			int EOPL_L_FP_FGF_count = 0;
			int FLI_L_FD_FGF_count = 0;
			int MPC_LM_FGF_count = 0;
			int MPC_LM_OEF_count = 0;
			int SEF_count = 0;
			int FJ_DU_LDA_FGF_ZIP_count = 0;
			int FJ_DU_LDB_FGF_ZIP_count = 0;
			int FJ_DU_LDC_FGF_ZIP_count = 0;
			int FJ_RU_RCA_FGF_ZIP_count = 0;
			


			if (DataCtrl.DataCtrl.Instance.currentTestState == DataCtrl.DataCtrl.ENUM_DATACTRL_TEST_STATE.TERMINATION)
			{
				dataGridView_TestItem.Rows[this.testIndex].Cells[1].Value = "実行终止:時間" + formatDateTime((DataCtrl.DataCtrl.Instance.taskProcess.ExitTime - nowTime).ToString("ss"));
				mtimeThread.Abort();
                dataGridView_TestItem.Rows[this.testIndex].Cells[2].Value = "00:00:00";
				return;
			}


			if (DataCtrl.DataCtrl.Instance.taskProcess.ExitCode != 0)
			{
				dataGridView_TestItem.Rows[this.testIndex].Cells[1].Value = "実行NG:時間" + formatDateTime((DataCtrl.DataCtrl.Instance.taskProcess.ExitTime - nowTime).ToString("ss"));
				mtimeThread.Abort();
				dataGridView_TestItem.Rows[this.testIndex].Cells[2].Value = "00:00:00";

				//以下为判定fileset文件完整性
				string[] files = Directory.GetFiles(@"D:\CC\JidoukaTool\bin\Debug\fileset");//判定fileset文件是否符合要求，路径需要修改为输入值
				int fileNum = files.Length;//fileset文件个数

				if (fileNum < 23)
				{
					filesetcheck = "There is an error in the Fileset file";
				}

				for (int i= 0; i < files.Length; i++)
			    {
					if (files[i].Contains("BPR")&& files[i].Contains("FP") && files[i].Contains("FEF")) 
					{
						BPR_FP_FEF_count++;
					}
					if (files[i].Contains("CLK") && files[i].Contains("FD") && files[i].Contains("FEF"))
					{
						CLK_FD_FEF_count++;
					}
					if (files[i].Contains("DS") && files[i].Contains("FM") && files[i].Contains("FEF"))
					{
						DS_FM_FEF_count++;
					}
					if (files[i].Contains("DS") && files[i].Contains("FP") && files[i].Contains("FEF"))
					{
						DS_FP_FEF_count++;
					}
					if (files[i].Contains("EBLI") && files[i].Contains("BT") && files[i].Contains("FEF"))
					{
						EBLI_BT_FEF_count++;
					}
					if (files[i].Contains("EBLI") && files[i].Contains("FP") && files[i].Contains("FEF"))
					{
						EBLI_FP_FEF_count++;
					}
					if (files[i].Contains("EBLI") && files[i].Contains("NWP") && files[i].Contains("FEF"))
					{
						EBLI_NWP_FEF_count++;
					}
					if (files[i].Contains("MPC") && files[i].Contains("BT") && files[i].Contains("FEF"))
					{
						MPC_BT_FEF_count++;					}

					if (files[i].Contains("MPC") && files[i].Contains("CPU") && files[i].Contains("FEF"))
					{
						MPC_CPU_FEF_count++;
					}
					if (files[i].Contains("MPC") && files[i].Contains("FP") && files[i].Contains("FEF"))
					{
						MPC_FP_FEF_count++;
					}
					if (files[i].Contains("BB") && files[i].Contains("FD") && files[i].Contains("FGF"))
					{
						BB_FD_FGF_count++;
					}
					if (files[i].Contains("ELL_L") && files[i].Contains("FD") && files[i].Contains("FGF"))
					{
						ELL_L_FD_FGF_count++;
					}
					if (files[i].Contains("EOPL_L") && files[i].Contains("FP") && files[i].Contains("FGF"))
					{
						EOPL_L_FP_FGF_count++;
					}
					if (files[i].Contains("FLI_L") && files[i].Contains("FD") && files[i].Contains("FGF"))
					{
						FLI_L_FD_FGF_count++;
					}
					if (files[i].Contains("MPC") && files[i].Contains("LM") && files[i].Contains("FGF"))
					{
						MPC_LM_FGF_count++;
					}
					if (files[i].Contains("MPC") && files[i].Contains("LM") && files[i].Contains("OEF"))
					{
						MPC_LM_OEF_count++;
					}

					if (files[i].Contains(".SEF"))//局数据
					{
						SEF_count++;
					}


					if (files[i].Contains("FJ-DU-LDA") && files[i].Contains("FGF") && files[i].Contains("zip"))
					{
						FJ_DU_LDA_FGF_ZIP_count++;
					}
					if (files[i].Contains("FJ-DU-LDB") && files[i].Contains("FGF") && files[i].Contains("zip"))
					{
						FJ_DU_LDB_FGF_ZIP_count++;
					}
					if (files[i].Contains("FJ-DU-LDC") && files[i].Contains("FGF") && files[i].Contains("zip"))
					{
						FJ_DU_LDC_FGF_ZIP_count++;
					}
					if (files[i].Contains("FJ-RU-RCA") && files[i].Contains("FGF") && files[i].Contains("zip"))
					{
						FJ_RU_RCA_FGF_ZIP_count++;
					}		

				}

				if (BPR_FP_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost BPR_FP_FEF";
				}
				if (CLK_FD_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost CLK_FD_FEF";
				}
				if (DS_FM_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost DS_FM_FEF";
				}
				if (DS_FP_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost DS_FP_FEF";
				}
				if (EBLI_BT_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost EBLI_BT_FEF";
				}
				if (EBLI_FP_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost EBLI_FP_FEF";
				}
				if (EBLI_NWP_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost EBLI_NWP_FEF";
				}
				if (MPC_BT_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost MPC_BT_FEF";
				}
				if (MPC_CPU_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost MPC_CPU_FEF";
				}
				if (MPC_FP_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost MPC_FP_FEF";
				}
				if (BB_FD_FGF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost BB_FD_FGF";
				}
				if (ELL_L_FD_FGF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost ELL_L_FD_FGF";
				}
				if (EOPL_L_FP_FGF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost EOPL_L_FP_FGF";
				}
				if (FLI_L_FD_FGF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost FLI_L_FD_FGF";
				}
				if (MPC_LM_OEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost MPC_LM_OEF";
				}
				if (SEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost SEF";
				}
				if (FJ_DU_LDA_FGF_ZIP_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost FJ_DU_LDA_FGF";
				}
				if (FJ_DU_LDB_FGF_ZIP_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost FJ_DU_LDB_FGF";
				}
				if (FJ_DU_LDC_FGF_ZIP_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost FJ_DU_LDC_FGF";
				}
				if (FJ_RU_RCA_FGF_ZIP_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost FJ_RU_RCA_FGF";
				}


				//项目NG的情况下，记录异常log
				string starttime = nowTime.ToString();
				string endtime = DataCtrl.DataCtrl.Instance.taskProcess.ExitTime.ToString();
				if (!System.IO.File.Exists(@".\output\logtest" + this.testIndex.ToString() + ".txt"))
				{
					//没有则创建这个文件
					FileStream fs1 = new FileStream(@".\output\logtest" + this.testIndex.ToString() + ".txt", FileMode.Create, FileAccess.Write);//创建写入文件                //设置文件属性为隐藏
					//System.IO.File.SetAttributes(@".\output\logtest.txt", FileAttributes.Hidden);
					StreamWriter sw = new StreamWriter(fs1);


					sw.WriteLine("StartTime：" + starttime.Trim() + "   " + "EndTime：" + endtime.Trim());//开始写入值
					sw.WriteLine(csv1ifexit.Trim());//开始写入值
					sw.WriteLine(csv2ifexit.Trim());//开始写入值
					sw.WriteLine(filesetcheck.Trim());//开始写入值
					sw.Close();
					fs1.Close();

				}
				else
				{
					FileStream fs = new FileStream(@".\output\logtest" + this.testIndex.ToString() + ".txt", FileMode.Open, FileAccess.Write);
					//System.IO.File.SetAttributes(@".\output\logtest.txt", FileAttributes.Hidden);
					StreamWriter sr = new StreamWriter(fs);


					sr.WriteLine("StartTime：" + starttime.Trim() + "   " + "EndTime：" + endtime.Trim());//开始写入值
					sr.WriteLine(csv1ifexit.Trim());//开始写入值
					sr.WriteLine(csv2ifexit.Trim());//开始写入值
					sr.WriteLine(filesetcheck.Trim());//开始写入值
					sr.Close();
					fs.Close();
				}

			}
			else
			{

				if ((csv1ifexit.Contains("no"))|(csv2ifexit.Contains("no")))
				{
					goto Label1;
				}
				dataGridView_TestItem.Rows[this.testIndex].Cells[1].Value = "実行OK:時間" + formatDateTime((DataCtrl.DataCtrl.Instance.taskProcess.ExitTime - nowTime).ToString("ss"));//并显示结束时间
				mtimeThread.Abort();
				dataGridView_TestItem.Rows[this.testIndex].Cells[2].Value = "00:00:00";
			//this.testIndex.clear;
			//以下为判定fileset文件完整性
			Label1: string[] files = Directory.GetFiles(fileSetPath);//判定fileset文件是否符合要求，路径需要修改为输入值
				int fileNum = files.Length;//fileset文件个数

				if (fileNum < 23)
				{
					filesetcheck = "There is an error in the Fileset file";
				}

				for (int i = 0; i < files.Length; i++)
				{
					if (files[i].Contains("BPR") && files[i].Contains("FP") && files[i].Contains("FEF"))
					{
						BPR_FP_FEF_count++;
					}
					if (files[i].Contains("CLK") && files[i].Contains("FD") && files[i].Contains("FEF"))
					{
						CLK_FD_FEF_count++;
					}
					if (files[i].Contains("DS") && files[i].Contains("FM") && files[i].Contains("FEF"))
					{
						DS_FM_FEF_count++;
					}
					if (files[i].Contains("DS") && files[i].Contains("FP") && files[i].Contains("FEF"))
					{
						DS_FP_FEF_count++;
					}
					if (files[i].Contains("EBLI") && files[i].Contains("BT") && files[i].Contains("FEF"))
					{
						EBLI_BT_FEF_count++;
					}
					if (files[i].Contains("EBLI") && files[i].Contains("FP") && files[i].Contains("FEF"))
					{
						EBLI_FP_FEF_count++;
					}
					if (files[i].Contains("EBLI") && files[i].Contains("NWP") && files[i].Contains("FEF"))
					{
						EBLI_NWP_FEF_count++;
					}
					if (files[i].Contains("MPC") && files[i].Contains("BT") && files[i].Contains("FEF"))
					{
						MPC_BT_FEF_count++;
					}

					if (files[i].Contains("MPC") && files[i].Contains("CPU") && files[i].Contains("FEF"))
					{
						MPC_CPU_FEF_count++;
					}
					if (files[i].Contains("MPC") && files[i].Contains("FP") && files[i].Contains("FEF"))
					{
						MPC_FP_FEF_count++;
					}
					if (files[i].Contains("BB") && files[i].Contains("FD") && files[i].Contains("FGF"))
					{
						BB_FD_FGF_count++;
					}
					if (files[i].Contains("ELL_L") && files[i].Contains("FD") && files[i].Contains("FGF"))
					{
						ELL_L_FD_FGF_count++;
					}
					if (files[i].Contains("EOPL_L") && files[i].Contains("FP") && files[i].Contains("FGF"))
					{
						EOPL_L_FP_FGF_count++;
					}
					if (files[i].Contains("FLI_L") && files[i].Contains("FD") && files[i].Contains("FGF"))
					{
						FLI_L_FD_FGF_count++;
					}
					if (files[i].Contains("MPC") && files[i].Contains("LM") && files[i].Contains("FGF"))
					{
						MPC_LM_FGF_count++;
					}
					if (files[i].Contains("MPC") && files[i].Contains("LM") && files[i].Contains("OEF"))
					{
						MPC_LM_OEF_count++;
					}

					if (files[i].Contains(".SEF"))//局数据
					{
						SEF_count++;
					}


					if (files[i].Contains("FJ-DU-LDA") && files[i].Contains("FGF") && files[i].Contains("zip"))
					{
						FJ_DU_LDA_FGF_ZIP_count++;
					}
					if (files[i].Contains("FJ-DU-LDB") && files[i].Contains("FGF") && files[i].Contains("zip"))
					{
						FJ_DU_LDB_FGF_ZIP_count++;
					}
					if (files[i].Contains("FJ-DU-LDC") && files[i].Contains("FGF") && files[i].Contains("zip"))
					{
						FJ_DU_LDC_FGF_ZIP_count++;
					}
					if (files[i].Contains("FJ-RU-RCA") && files[i].Contains("FGF") && files[i].Contains("zip"))
					{
						FJ_RU_RCA_FGF_ZIP_count++;
					}

				}

				if (BPR_FP_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost BPR_FP_FEF";
				}
				if (CLK_FD_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost CLK_FD_FEF";
				}
				if (DS_FM_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost DS_FM_FEF";
				}
				if (DS_FP_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost DS_FP_FEF";
				}
				if (EBLI_BT_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost EBLI_BT_FEF";
				}
				if (EBLI_FP_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost EBLI_FP_FEF";
				}
				if (EBLI_NWP_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost EBLI_NWP_FEF";
				}
				if (MPC_BT_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost MPC_BT_FEF";
				}
				if (MPC_CPU_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost MPC_CPU_FEF";
				}
				if (MPC_FP_FEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost MPC_FP_FEF";
				}
				if (BB_FD_FGF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost BB_FD_FGF";
				}
				if (ELL_L_FD_FGF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost ELL_L_FD_FGF";
				}
				if (EOPL_L_FP_FGF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost EOPL_L_FP_FGF";
				}
				if (FLI_L_FD_FGF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost FLI_L_FD_FGF";
				}
				if (MPC_LM_OEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost MPC_LM_OEF";
				}
				if (SEF_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost SEF";
				}
				if (FJ_DU_LDA_FGF_ZIP_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost FJ_DU_LDA_FGF";
				}
				if (FJ_DU_LDB_FGF_ZIP_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost FJ_DU_LDB_FGF";
				}
				if (FJ_DU_LDC_FGF_ZIP_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost FJ_DU_LDC_FGF";
				}
				if (FJ_RU_RCA_FGF_ZIP_count == 0)
				{
					filesetcheck = filesetcheck + "\n" + "There is an error in the Fileset file：lost FJ_RU_RCA_FGF";
				}

				//6月18号项目ok的清空下，记录caselog
				string starttime = nowTime.ToString();
				string endtime = DataCtrl.DataCtrl.Instance.taskProcess.ExitTime.ToString();
				if (!System.IO.File.Exists(@".\output\logtest" + this.testIndex.ToString() + ".txt"))
				{
					//没有则创建这个文件
					FileStream fs1 = new FileStream(@".\output\logtest" + this.testIndex.ToString() + ".txt", FileMode.Create, FileAccess.Write);//创建写入文件                //设置文件属性为隐藏
																												//System.IO.File.SetAttributes(@".\output\logtest.txt", FileAttributes.Hidden);
					StreamWriter sw = new StreamWriter(fs1);
					sw.WriteLine("StartTime：" + starttime.Trim() + "   " + "EndTime：" + endtime.Trim());//开始写入值 如果项目OK，只会记录开始时间和结束时间，不会记录其他log信息
					sw.WriteLine(csv1ifexit);
					sw.WriteLine(csv2ifexit);
					sw.Close();
					fs1.Close();

				}
				else
				{
					FileStream fs = new FileStream(@".\output\logtest" + this.testIndex.ToString() + ".txt", FileMode.Create, FileAccess.Write);
					//System.IO.File.SetAttributes(@".\output\logtest.txt", FileAttributes.Hidden);
					StreamWriter sr = new StreamWriter(fs);
					sr.WriteLine("StartTime：" + starttime.Trim() + "   " + "EndTime：" + endtime.Trim());//开始写入值
					sr.WriteLine(csv1ifexit);
					sr.WriteLine(csv2ifexit);
					sr.Close();
					fs.Close();

				}


                if (DataCtrl.DataCtrl.Instance.taskProcess.ExitCode == 0 && cpLogsave)
				{
					CopylogFolder(@".\output", logSavePath);//试验执行成功，并触发log文件另存为操作

				}
			}


			if (DataCtrl.DataCtrl.Instance.currentTestState != DataCtrl.DataCtrl.ENUM_DATACTRL_TEST_STATE.STOP &&
				(this.testIndex+1  < this.runItemList.Count) )
			{
				this.testIndex++;
				string filePath = @".\TestRun.bat";//生成bat文件
				if (!File.Exists(filePath))
				{
					FileStream fs1 = new FileStream(filePath, FileMode.Create, FileAccess.Write);//创建写入文件
					StreamWriter sw = new StreamWriter(fs1, Encoding.GetEncoding(932));

					//sw.WriteLine(@"route print  >%~dp0\output\1.txt%");

					string command_setting3 = this.runItemList[this.testIndex].command_setting;
					string command_csv3	= this.runItemList[this.testIndex].command_csv;
					if (command_setting3.Contains("{"))
					{
						command_setting3 = command_setting3.Replace("{", "{{");
					}
					if (command_setting3.Contains("}"))
					{
						command_setting3 = command_setting3.Replace("}", "}}");
					}

					if (command_csv3.Contains("{"))
					{
						command_csv3 = command_csv3.Replace("{", "{{");
					}
					if (command_csv3.Contains("}"))
					{
						command_csv3 = command_csv3.Replace("}", "}}");
					}

					sw.WriteLine(@"C:\Windows\System32\cscript //nologo %~dp0S3G.vbs"
								 + @" " + command_setting3
								 + @" " + command_csv3
								 + @" C:\MTSTSVR\sftp\log %~dp0mtstlog" + "\n"
								 + @"echo 'MTST:batch-END'", Encoding.GetEncoding(932));//开始写入值
					sw.Close();
					fs1.Close();
				}
				else
				{
					FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
					StreamWriter sr = new StreamWriter(fs, Encoding.GetEncoding(932));
					//sr.WriteLine(@"route print  >%~dp0\output\1.txt%");
					string command_setting4 = this.runItemList[this.testIndex].command_setting;
					string command_csv4 = this.runItemList[this.testIndex].command_csv;
					if (command_setting4.Contains("{"))
					{
						command_setting4 = command_setting4.Replace("{", "{{");
					}
					if (command_setting4.Contains("}"))
					{
						command_setting4 = command_setting4.Replace("}", "}}");
					}

					if (command_csv4.Contains("{"))
					{
						command_csv4 = command_csv4.Replace("{", "{{");
					}
					if (command_csv4.Contains("}"))
					{
						command_csv4 = command_csv4.Replace("}", "}}");
					}
						sr.WriteLine(@"C:\Windows\System32\cscript //nologo %~dp0S3G.vbs"
								 + @" " + command_setting4
								 + @" " + command_csv4
								 + @" C:\MTSTSVR\sftp\log %~dp0mtstlog" + "\n"
								 + @"echo 'MTST:batch-END'", Encoding.GetEncoding(932));//开始写入值
					sr.Close();
					fs.Close();
				}


				try//以下为bat执行
				{
					string targetDir = string.Format(@"");//this is where 1.bat lies    @"../../../"
					DataCtrl.DataCtrl.Instance.taskProcess = new Process();
					DataCtrl.DataCtrl.Instance.taskProcess.StartInfo.WorkingDirectory = targetDir;
					DataCtrl.DataCtrl.Instance.taskProcess.StartInfo.FileName = filePath;   //this.runItemList[this.testIndex].command_setting;//将执行的文件名是TestRun.bat
					DataCtrl.DataCtrl.Instance.taskProcess.StartInfo.Arguments = this.runItemList[this.testIndex].command_csv;//this is argument 将csv2传递过来
																															  //proc.StartInfo.CreateNoWindow = true;
																															  //proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;//这里设置DOS窗口不显示，经实践可行

					DataCtrl.DataCtrl.Instance.taskProcess.Start();
					DataCtrl.DataCtrl.Instance.taskProcess.EnableRaisingEvents = true;
					this.nowTime = DateTime.Now;
					DataCtrl.DataCtrl.Instance.taskProcess.Exited += process_exit;

					dataGridView_TestItem.Rows[this.testIndex].Cells[1].Value = "実施中...";//显示实施中
					//倒计时
					//MessageBox.Show(testIndex.ToString());
					TimeTread tt = new TimeTread(timeList[this.testIndex], dataGridView_TestItem.Rows[this.testIndex].Cells[2]);
					Thread th = new Thread(new ThreadStart(tt.timeCout));
					th.Start();
					mtimeThread = th;
				}

				catch (Exception ex)
				{
					MessageBox.Show("执行失败");
					Console.WriteLine("Exception Occurred :{0},{1}", ex.Message, ex.StackTrace.ToString());
				}


				if (!File.Exists(this.runItemList[this.testIndex].command_setting))//判定csv文件 setting_file 是否存在
				{
					csv1ifexit = "Execution error: The executed setting_file of CSV does not exist;";
				}
				else
				{
					csv1ifexit = "The executed setting_file of CSV exists;";
				}

				if (!File.Exists(this.runItemList[this.testIndex].command_csv))//判定csv文件 scenario 是否存在
				{
					csv2ifexit = "Execution error: The executed scenario of CSV does not exist;";
				}
				else
				{
					csv2ifexit = "The executed scenario of CSV exists;";
				}

			}
			else
			{
				DataCtrl.DataCtrl.Instance.currentTestState = DataCtrl.DataCtrl.ENUM_DATACTRL_TEST_STATE.STOP;
			}
		}

		
		
		public static void CopylogFolder(string strFromPath, string strToPath)
		{
			//如果目标文件夹不存在，则创建
			if (!Directory.Exists(strToPath))
			{
				MessageBox.Show("ロゴを保存するフォルダを設定してください。");
				//return;
				Environment.Exit(0);//直接退出

			}
			string nowTime = DateTime.Now.ToString("yyyyMMdd_hhmmss");
			//取得要拷贝的文件夹名
			string strFolderName = strFromPath.Substring(strFromPath.LastIndexOf("\\") + 1, strFromPath.Length - strFromPath.LastIndexOf("\\") - 1)+ nowTime;//5月20日 strFolderName 在目标文件夹创建试验项目文件夹，目前先按时间
																																							   
			if (!Directory.Exists(strToPath + "\\" + strFolderName))
			{
				Directory.CreateDirectory(strToPath + "\\" + strFolderName);     
			}
			//创建数组保存源文件夹下的文件名
			string[] strFiles = Directory.GetFiles(strFromPath);
			//循环拷贝文件
			for (int i = 0; i < strFiles.Length; i++)
			{
				//取得拷贝的文件名，只取文件名，地址截掉。
				string strFileName = strFiles[i].Substring(strFiles[i].LastIndexOf("\\") + 1, strFiles[i].Length - strFiles[i].LastIndexOf("\\") - 1);
				//开始拷贝文件,true表示覆盖同名文件
				File.Copy(strFiles[i], strToPath + "\\" + strFolderName + "\\" + strFileName, true);
			}
			//创建DirectoryInfo实例
			DirectoryInfo dirInfo = new DirectoryInfo(strFromPath);
			//取得源文件夹下的所有子文件夹名称
			DirectoryInfo[] ZiPath = dirInfo.GetDirectories();
			for (int j = 0; j < ZiPath.Length; j++)
			{
				//获取所有子文件夹名
				string strZiPath = strFromPath + "\\" + ZiPath[j].ToString();
				//把得到的子文件夹当成新的源文件夹，从头开始新一轮的拷贝
				CopylogFolder(strZiPath, strToPath + "\\" + strFolderName);
			}
		}

		private void dataGridView_TestItem_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}
		public class TimeTread//倒计时线程类
        {
			private int mtine;
			private DataGridViewCell mcell;
			public TimeTread(int a, DataGridViewCell b)
            {
				mtine = a;
				mcell = b;
			}
			public void timeCout()
            {
                while (mtine>1)
                {
					Thread.Sleep(1000);
					mtine--;
					TimeSpan tmp = new TimeSpan(0, 0, mtine);
					mcell.Value = string.Format("{0:00}:{1:00}:{2:00}", tmp.Hours, tmp.Minutes, tmp.Seconds);
				}
				
			}
		}
	}
}
