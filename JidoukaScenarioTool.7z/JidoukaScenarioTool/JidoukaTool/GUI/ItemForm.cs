using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JidoukaTool.GUI
{
    public partial class ItemForm : Form
    {
        public string name { get; private set; }
        public string setting_path { get; private set; }
        public string csv_path { get; private set; }
        public ItemForm(string name = "", string setting_path = "", string csv_path = "")
        {
            InitializeComponent();
            this.name = name;
            this.setting_path = setting_path;
            this.csv_path = csv_path;
        }

        private void ItemForm_Load(object sender, EventArgs e)
        {
            textBox_name.Text = this.name;
            textBox_settingPath.Text = this.setting_path;
            textBox_csvPath.Text = this.csv_path;
        }

        private void button_settingPath_Click(object sender, EventArgs e)
        {

        }

        private void button_csvPath_Click(object sender, EventArgs e)
        {

        }

        private void textBox_settingPath_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_csvPath_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_OK_Click(object sender, EventArgs e)
        {
            this.name = textBox_name.Text;
            this.setting_path = textBox_settingPath.Text;
            this.csv_path = textBox_csvPath.Text;
            //List<TestItem> list = DataCtrl.DataCtrl.Instance.getCurrentPhaseTestList();
            this.DialogResult = DialogResult.OK;
            if (this.DialogResult == DialogResult.OK)
            {
                //添加写入xml的操作               

                //=this.name;
                //=this.setting_path;
                //=this.csv_path;
                Close();
            }



        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
            //this.DialogResult = DialogResult.Cancel;
            Close();
            
        }

        private void pathButton_Click(object sender, EventArgs e)
        {
            if (openFileDialog_file.ShowDialog() == DialogResult.OK)
            {
                string path = openFileDialog_file.FileName;

                if (button_settingPath == sender as Button)
                {
                    textBox_settingPath.Text = path;
                }
                else if (button_csvPath == sender as Button)
                {
                    textBox_csvPath.Text = path;
                }
            }
        }

        private void textBox_name_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
